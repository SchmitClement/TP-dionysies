#!/bin/sh

# Ce script permet de générer la documentation de la classe Tournoi

javadoc -doctitle Tournoi -package dionysies -d doc_tournoi
